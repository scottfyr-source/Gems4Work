discogs\_client.client module
=============================

.. automodule:: discogs_client.client

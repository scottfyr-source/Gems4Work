discogs\_client.exceptions module
=================================

.. automodule:: discogs_client.exceptions


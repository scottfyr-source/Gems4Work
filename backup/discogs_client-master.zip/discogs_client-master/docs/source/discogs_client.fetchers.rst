discogs\_client.fetchers module
===============================

.. automodule:: discogs_client.fetchers


.. python3-discogs-client documentation master file, created by
   sphinx-quickstart on Wed Apr 28 08:45:42 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

python3-discogs-client documentation
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about.md
   quickstart.md
   authentication.md
   fetching_data.md
   fetching_data_repl.md
   listing.md
   optional_configuration.md
   contributing.md
   writing_docs.md
   index_discogs_client


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
